import cookie from 'cookie';
import {v4 as uuid} from '@lukeed/uuid';
import type {Handle} from '@sveltejs/kit';

export const handle: Handle = async ({event, resolve}) => {
  const cookies       = cookie.parse(event.request.headers.get('cookie') || '');
  event.locals.userid = cookies.userid || uuid();
  
  const response = await resolve(event, {
    ssr          : false,
    transformPage: ({html}) => html.replace('old', 'new')
  });
  
  if (!cookies.userid) {
    // if this is the first time the user has visited this app,
    // set a cookie so that we recognise them when they return
    response.headers.set(
      'set-cookie',
      cookie.serialize('userid', event.locals.userid, {
        path    : '/',
        httpOnly: true
      })
    );
  }
  
  return response;
};
