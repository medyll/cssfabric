import type { CssfInterfaceT } from './cssfLib.js';
export declare const cssfTransformer: CssfInterfaceT;
