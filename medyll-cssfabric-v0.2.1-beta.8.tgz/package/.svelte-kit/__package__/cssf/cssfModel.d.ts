export type CssfModelTypes = typeof cssfModelTypes;
export type cssfModelRoot = Record<string, cssfModelDeclaration>;
export type cssfModelDeclaration = Record<string, any>;
export declare const cssfModelTypes: string[];
/**
 * Display property of the outer element
 */
export declare const cssfModel: cssfModelRoot;
