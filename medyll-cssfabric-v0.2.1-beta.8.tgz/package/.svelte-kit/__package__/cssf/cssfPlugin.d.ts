import postcss from 'postcss';
export declare const myPlugin: () => (root: postcss.Root) => void;
export declare const cssfProcessor: postcss.Processor;
