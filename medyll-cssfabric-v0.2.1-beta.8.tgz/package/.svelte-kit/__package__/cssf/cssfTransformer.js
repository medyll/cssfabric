export const cssfTransformer = {
    gutter: {
        type: function (decl, ...value) {
            throw new Error('Function not implemented.');
        },
        gap: function (decl, ...value) {
            throw new Error('Function not implemented.');
        },
        padding: function (decl, ...value) {
            throw new Error('Function not implemented.');
        }
    },
    position: {
        left: function (decl, ...value) {
            throw new Error('Function not implemented.');
        },
        top: function (decl, ...value) {
            throw new Error('Function not implemented.');
        },
        right: function (decl, ...value) {
            throw new Error('Function not implemented.');
        },
        bottom: function (decl, ...value) {
            throw new Error('Function not implemented.');
        },
        margin: function (decl, ...value) {
            throw new Error('Function not implemented.');
        }
    },
    box: {
        border: function (decl, ...value) {
            throw new Error('Function not implemented.');
        },
        shadow: function (decl, ...value) {
            throw new Error('Function not implemented.');
        },
        radius: function (decl, ...value) {
            throw new Error('Function not implemented.');
        },
        overflow: function (decl, ...value) {
            throw new Error('Function not implemented.');
        }
    },
    size: {
        width: function (decl, ...value) {
            throw new Error('Function not implemented.');
        },
        height: function (decl, ...value) {
            throw new Error('Function not implemented.');
        },
        ratio: function (decl, ...value) {
            throw new Error('Function not implemented.');
        }
    },
    typography: {
        font: function (decl, ...value) {
            throw new Error('Function not implemented.');
        },
        size: function (decl, ...value) {
            throw new Error('Function not implemented.');
        },
        style: function (decl, ...value) {
            throw new Error('Function not implemented.');
        },
        underline: function (decl, ...value) {
            throw new Error('Function not implemented.');
        },
        shadow: function (decl, ...value) {
            throw new Error('Function not implemented.');
        }
    },
    color: {
        text: function (decl, ...value) {
            throw new Error('Function not implemented.');
        },
        bg: function (decl, ...value) {
            throw new Error('Function not implemented.');
        },
        opacity: function (decl, ...value) {
            throw new Error('Function not implemented.');
        }
    },
    animate: {
        transition: function (decl, ...value) {
            throw new Error('Function not implemented.');
        },
        all: function (decl, ...value) {
            throw new Error('Function not implemented.');
        },
        duration: function (decl, ...value) {
            throw new Error('Function not implemented.');
        },
        timing: function (decl, ...value) {
            throw new Error('Function not implemented.');
        },
        delay: function (decl, ...value) {
            throw new Error('Function not implemented.');
        }
    }
};
