/** generated ! */
import postcss from 'postcss';
export class CssfClass {
    gutter(decl) {
        return {
            type: (...args) => {
                return args;
            },
            gap: (...args) => {
                return args;
            },
            padding: (...args) => {
                return args;
            },
        };
    }
    position(decl) {
        return {
            left: (...args) => {
                return args;
            },
            top: (...args) => {
                return args;
            },
            right: (...args) => {
                return args;
            },
            bottom: (...args) => {
                return args;
            },
            margin: (...args) => {
                return args;
            },
        };
    }
    box(decl) {
        return {
            border: (...args) => {
                return args;
            },
            shadow: (...args) => {
                return args;
            },
            radius: (...args) => {
                return args;
            },
            overflow: (...args) => {
                return args;
            },
        };
    }
    size(decl) {
        return {
            width: (...args) => {
                return args;
            },
            height: (...args) => {
                return args;
            },
            ratio: (...args) => {
                return args;
            },
        };
    }
    typography(decl) {
        return {
            font: (...args) => {
                return args;
            },
            size: (...args) => {
                return args;
            },
            style: (...args) => {
                return args;
            },
            underline: (...args) => {
                return args;
            },
            shadow: (...args) => {
                return args;
            },
        };
    }
    color(decl) {
        return {
            text: (...args) => {
                return args;
            },
            bg: (...args) => {
                return args;
            },
            opacity: (...args) => {
                return args;
            },
        };
    }
    animate(decl) {
        return {
            transition: (...args) => {
                return args;
            },
            all: (...args) => {
                return args;
            },
            duration: (...args) => {
                return args;
            },
            timing: (...args) => {
                return args;
            },
            delay: (...args) => {
                return args;
            },
        };
    }
}
