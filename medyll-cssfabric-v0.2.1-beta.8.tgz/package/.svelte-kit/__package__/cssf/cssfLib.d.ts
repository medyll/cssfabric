/** generated ! */
import postcss from 'postcss';
export interface CssfInterfaceT {
    gutter: {
        type: (decl: postcss.Declaration, ...value: CssfInterface['gutter']['type'][]) => void;
        gap: (decl: postcss.Declaration, ...value: CssfInterface['gutter']['gap'][]) => void;
        padding: (decl: postcss.Declaration, ...value: CssfInterface['gutter']['padding'][]) => void;
    };
    position: {
        left: (decl: postcss.Declaration, ...value: CssfInterface['position']['left'][]) => void;
        top: (decl: postcss.Declaration, ...value: CssfInterface['position']['top'][]) => void;
        right: (decl: postcss.Declaration, ...value: CssfInterface['position']['right'][]) => void;
        bottom: (decl: postcss.Declaration, ...value: CssfInterface['position']['bottom'][]) => void;
        margin: (decl: postcss.Declaration, ...value: CssfInterface['position']['margin'][]) => void;
    };
    box: {
        border: (decl: postcss.Declaration, ...value: CssfInterface['box']['border'][]) => void;
        shadow: (decl: postcss.Declaration, ...value: CssfInterface['box']['shadow'][]) => void;
        radius: (decl: postcss.Declaration, ...value: CssfInterface['box']['radius'][]) => void;
        overflow: (decl: postcss.Declaration, ...value: CssfInterface['box']['overflow'][]) => void;
    };
    size: {
        width: (decl: postcss.Declaration, ...value: CssfInterface['size']['width'][]) => void;
        height: (decl: postcss.Declaration, ...value: CssfInterface['size']['height'][]) => void;
        ratio: (decl: postcss.Declaration, ...value: CssfInterface['size']['ratio'][]) => void;
    };
    typography: {
        font: (decl: postcss.Declaration, ...value: CssfInterface['typography']['font'][]) => void;
        size: (decl: postcss.Declaration, ...value: CssfInterface['typography']['size'][]) => void;
        style: (decl: postcss.Declaration, ...value: CssfInterface['typography']['style'][]) => void;
        underline: (decl: postcss.Declaration, ...value: CssfInterface['typography']['underline'][]) => void;
        shadow: (decl: postcss.Declaration, ...value: CssfInterface['typography']['shadow'][]) => void;
    };
    color: {
        text: (decl: postcss.Declaration, ...value: CssfInterface['color']['text'][]) => void;
        bg: (decl: postcss.Declaration, ...value: CssfInterface['color']['bg'][]) => void;
        opacity: (decl: postcss.Declaration, ...value: CssfInterface['color']['opacity'][]) => void;
    };
    animate: {
        transition: (decl: postcss.Declaration, ...value: CssfInterface['animate']['transition'][]) => void;
        all: (decl: postcss.Declaration, ...value: CssfInterface['animate']['all'][]) => void;
        duration: (decl: postcss.Declaration, ...value: CssfInterface['animate']['duration'][]) => void;
        timing: (decl: postcss.Declaration, ...value: CssfInterface['animate']['timing'][]) => void;
        delay: (decl: postcss.Declaration, ...value: CssfInterface['animate']['delay'][]) => void;
    };
}
export interface CssfInterface {
    gutter: {
        type: 'flex' | 'grid';
        gap: 'string';
        padding: 'all' | ['top' | 'bottom'] | ['top' | 'bottom' | 'left' | 'right'];
    };
    position: {
        left: 'string';
        top: 'string';
        right: 'string';
        bottom: 'string';
        margin: 'all' | ['top' | 'bottom'] | ['top' | 'bottom' | 'left' | 'right'];
    };
    box: {
        border: 'all' | ['top' | 'bottom'] | ['top' | 'bottom' | 'left' | 'right'];
        shadow: [];
        radius: 'string' | 'string?' | 'string?' | 'string?';
        overflow: ['visible | hidden' | ['x' | 'y']];
    };
    size: {
        width: 'string' | 'min?' | 'max?';
        height: 'string' | 'min?' | 'max?';
        ratio: 'string , string?';
    };
    typography: {
        font: 'string';
        size: 'string';
        style: 'bold' | 'italic' | 'normal' | 'string';
        underline: 'none' | 'dotted' | 'dashed' | 'solid' | 'double' | 'wavy' | 'string';
        shadow: 'string' | 'string?' | 'string?' | 'string?';
    };
    color: {
        text: 'string';
        bg: 'string';
        opacity: 'string' | 'number';
    };
    animate: {
        transition: ['duration' | 'timing' | 'delay'];
        all: 'all' | 'none' | 'cssProp';
        duration: 'string';
        timing: 'string';
        delay: 'string';
    };
}
export declare class CssfClass {
    gutter(decl: postcss.Declaration): {
        type: (...args: CssfInterface["gutter"]["type"][]) => ("flex" | "grid")[];
        gap: (...args: CssfInterface["gutter"]["gap"][]) => "string"[];
        padding: (...args: CssfInterface["gutter"]["padding"][]) => ("all" | ["top" | "bottom"] | ["top" | "bottom" | "left" | "right"])[];
    };
    position(decl: postcss.Declaration): {
        left: (...args: CssfInterface["position"]["left"][]) => "string"[];
        top: (...args: CssfInterface["position"]["top"][]) => "string"[];
        right: (...args: CssfInterface["position"]["right"][]) => "string"[];
        bottom: (...args: CssfInterface["position"]["bottom"][]) => "string"[];
        margin: (...args: CssfInterface["position"]["margin"][]) => ("all" | ["top" | "bottom"] | ["top" | "bottom" | "left" | "right"])[];
    };
    box(decl: postcss.Declaration): {
        border: (...args: CssfInterface["box"]["border"][]) => ("all" | ["top" | "bottom"] | ["top" | "bottom" | "left" | "right"])[];
        shadow: (...args: CssfInterface["box"]["shadow"][]) => [][];
        radius: (...args: CssfInterface["box"]["radius"][]) => ("string" | "string?")[];
        overflow: (...args: CssfInterface["box"]["overflow"][]) => ["visible | hidden" | ["x" | "y"]][];
    };
    size(decl: postcss.Declaration): {
        width: (...args: CssfInterface["size"]["width"][]) => ("string" | "min?" | "max?")[];
        height: (...args: CssfInterface["size"]["height"][]) => ("string" | "min?" | "max?")[];
        ratio: (...args: CssfInterface["size"]["ratio"][]) => "string , string?"[];
    };
    typography(decl: postcss.Declaration): {
        font: (...args: CssfInterface["typography"]["font"][]) => "string"[];
        size: (...args: CssfInterface["typography"]["size"][]) => "string"[];
        style: (...args: CssfInterface["typography"]["style"][]) => ("string" | "bold" | "italic" | "normal")[];
        underline: (...args: CssfInterface["typography"]["underline"][]) => ("string" | "none" | "dotted" | "dashed" | "solid" | "double" | "wavy")[];
        shadow: (...args: CssfInterface["typography"]["shadow"][]) => ("string" | "string?")[];
    };
    color(decl: postcss.Declaration): {
        text: (...args: CssfInterface["color"]["text"][]) => "string"[];
        bg: (...args: CssfInterface["color"]["bg"][]) => "string"[];
        opacity: (...args: CssfInterface["color"]["opacity"][]) => ("string" | "number")[];
    };
    animate(decl: postcss.Declaration): {
        transition: (...args: CssfInterface["animate"]["transition"][]) => ["duration" | "timing" | "delay"][];
        all: (...args: CssfInterface["animate"]["all"][]) => ("all" | "none" | "cssProp")[];
        duration: (...args: CssfInterface["animate"]["duration"][]) => "string"[];
        timing: (...args: CssfInterface["animate"]["timing"][]) => "string"[];
        delay: (...args: CssfInterface["animate"]["delay"][]) => "string"[];
    };
}
