import type { CssfModelTypes } from './cssfModel.js';
export declare class CssGuide {
    cssfModelTypes: CssfModelTypes;
    interfaceName: string;
    className: string;
    constructor(cssfModel: CssfModelTypes);
    generate(objModel: Record<string, Record<string, any>>): {
        meta: string;
        classTypes: string;
        transformerTypes: string;
        interfaces: string;
        classMethods: string;
    };
}
