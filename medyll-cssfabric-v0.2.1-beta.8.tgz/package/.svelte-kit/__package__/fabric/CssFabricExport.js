import fsExtra from 'fs-extra';
export class CssFabricExport {
    cssFabricModel;
    exportPaths = {
        css: './css-fabric.css',
        json: './cssFabric.json'
    };
    constructor(cssFabricModel, exportPaths) {
        this.cssFabricModel = cssFabricModel;
        this.exportPaths = { ...exportPaths, ...this.exportPaths };
        return this;
    }
    export(options) {
        this.exportPaths = { ...this.exportPaths, ...options };
        this.createCssFile();
        this.createJsonModel();
    }
    createCssFile() {
        //this.parseModel(this.cssFabricModel);
        fsExtra.ensureFileSync(this.exportPaths.css);
        fsExtra.writeFile(this.exportPaths.css, this.parseModel(this.cssFabricModel), (err) => {
            if (err) {
                console.error(err);
                return;
            }
            console.log('File created successfully.');
        });
    }
    createJsonModel() {
        fsExtra.ensureFileSync(this.exportPaths.json);
        fsExtra.writeFile(this.exportPaths.json, JSON.stringify(this.cssFabricModel), (err) => {
            if (err) {
                console.error(err);
                return;
            }
            console.log('File created successfully.');
        });
    }
    parseModel(json, parentKey = '') {
        let css = parse(json, parentKey);
        return `:root{\n${css}}`;
        function parse(json, parentKey = '', titre = '') {
            let css = '';
            for (const key in json) {
                if (typeof json[key] === 'object') {
                    css += `\n/* ${key} */ `;
                    //titre += `/* ----${key}--- */ `;
                    css += parse(json[key], '', titre);
                }
                else {
                    css += titre;
                    css += `\n${parentKey}${key}: ${json[key]}`;
                    titre = '';
                }
            }
            return css;
        }
    }
}
