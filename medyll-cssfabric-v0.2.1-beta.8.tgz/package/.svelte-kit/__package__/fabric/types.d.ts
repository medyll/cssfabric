export type Steps = [number, number, number];
export type Mask = string;
export type ToMask = string;
export type EaseTrigger = number;
export type Ease = number;
export declare enum ModelConfigKeys {
    base = 0,
    palette = 1,
    presets = 2,
    status = 3,
    out = 4,
    gray = 5,
    out2 = 6
}
export type cssFabricModelKey = keyof typeof ModelConfigKeys;
export type cssFabricModelType = Record<cssFabricModelKey, any>;
