import type { CssFabricBlock } from './cssProperties.js';
export declare class CssFabricVariations {
    verticalModel: Record<string, any>;
    className: string;
    insert: string;
    constructor(model: Record<string, any>, options?: any);
    generateCss(prefix?: string): Record<string, any>;
    static loopVertical(): void;
    static loopVariations(fragmentObj: CssFabricBlock): Record<string, any>;
    private generateRoot;
    private generateCombinations;
}
