export var ModelConfigKeys;
(function (ModelConfigKeys) {
    ModelConfigKeys[ModelConfigKeys["base"] = 0] = "base";
    ModelConfigKeys[ModelConfigKeys["palette"] = 1] = "palette";
    ModelConfigKeys[ModelConfigKeys["presets"] = 2] = "presets";
    ModelConfigKeys[ModelConfigKeys["status"] = 3] = "status";
    ModelConfigKeys[ModelConfigKeys["out"] = 4] = "out";
    ModelConfigKeys[ModelConfigKeys["gray"] = 5] = "gray";
    ModelConfigKeys[ModelConfigKeys["out2"] = 6] = "out2";
})(ModelConfigKeys || (ModelConfigKeys = {}));
