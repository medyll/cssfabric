import { CssFabricBuilder, CssFabricBuilderParams } from './CssFabricBuilder.js';
import { CssFabricExport } from './CssFabricExport.js';
import type { cssFabricModelType, cssFabricModelKey } from './types.js';
/**
 * Represents a CSS Fabric class.
 */
export declare class CssFabric {
    /**
     * The vendor method returns a string with the vendor name and an optional fragment.
     * @param fragment - Optional fragment to append to the vendor name.
     * @returns A string with the vendor name and the fragment.
     */
    vendor: (fragment?: string) => string;
    cssFabricModel: cssFabricModelType;
    cssFabricBuilderParams: CssFabricBuilderParams;
    cssFabricBuilder: CssFabricBuilder;
    constructor();
    /**
     * Cleans the model key by removing single quotes.
     * @param modelKey - The model key to clean.
     * @returns The cleaned model key.
     */
    private cleanModelKey;
    /**
     * Sets the parameters for the CssFabricBuilder.
     * @param params - Partial parameters to set for the CssFabricBuilder.
     */
    setParams(params: Partial<CssFabricBuilderParams>): void;
    /**
     * Creates CSS fabric variables and colors based on the provided model keys.
     * @param args - The model keys to create CSS fabric variables and colors for.
     * @returns An object with the export and css properties.
     */
    createCssFabricVarsColors(...args: cssFabricModelKey[]): {
        export: CssFabricExport['export'];
        css: string;
    };
    /**
     * Generates the CSS fabric sheet.
     * @returns An object with the export and css properties.
     */
    cssFabricSheet(): {
        export: (options: any) => void;
        css: Record<string, any>;
    };
}
