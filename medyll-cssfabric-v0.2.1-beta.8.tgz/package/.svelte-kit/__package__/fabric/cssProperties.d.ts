export type CssFabricBlock = {
    [key: string]: {
        initial: string;
        syntax: string;
        fabric: Record<'classNames' | 'declinations' | 'variations', Record<string, string>>;
        variations: Record<string, string[] | string[][]>;
    };
};
export type CssFabricFragment = {
    description: string;
    syntax: string;
    template: string;
    initial: string;
    appliesTo: string;
    fabric: Record<'classNames' | 'declinations' | 'variations', Record<string, string>>;
    variations: Record<string, string>;
};
export type CssFabricPropertyFragment = Record<string, CssFabricFragment>;
export type CssFabricPropertyCatalog = Record<string, CssFabricPropertyFragment | CssFabricFragment>;
export declare class CSSProperties {
    private cssProperties;
    private onlyKeys;
    constructor(cssProperties: any, onlyKeys?: string[]);
    private chkValidity;
    private recursiveFabricSearch;
    generateCSS(): Record<string, any>;
}
