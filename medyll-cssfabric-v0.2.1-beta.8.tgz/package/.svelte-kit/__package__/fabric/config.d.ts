export declare const colorConfig: {
    theme: {
        primary: string;
        secondary: string;
        accent: string;
        neutral: string;
        error: string;
        gray: string;
    };
    palette: {
        yellow: string;
        orange: string;
        red: string;
        magenta: string;
        purple: string;
        green: string;
        teal: string;
        blue: string;
        dark: string;
    };
    status: {
        discrete: string;
        success: string;
        info: string;
        warning: string;
        alert: string;
        error: string;
    };
};
