export declare const cssFabricSheet: {
    appearance: {
        description: string;
        syntax: string;
        template: string;
        initial: string;
        appliesTo: string;
        fabric: {
            classNames: {
                appearance: string;
            };
        };
    };
    'object-fit': {
        description: string;
        syntax: string;
        template: string;
        initial: string;
        appliesTo: string;
        fabric: {
            classNames: {
                'object-fit': string;
            };
        };
    };
    'mix-blend-mode': {
        description: string;
        syntax: string;
        template: string;
        initial: string;
        appliesTo: string;
        fabric: {
            classNames: {
                'mix-blend-mode': string;
            };
        };
    };
    ol: {
        list: {
            description: string;
            syntax: string;
            template: string;
            initial: string;
            appliesTo: string;
            fabric: {
                variations: {
                    type: string;
                    position: string;
                    image: string;
                };
            };
        };
    };
    container: {
        flex: {
            description: string;
            syntax: string;
            template: string;
            initial: string;
            appliesTo: string;
            fabric: {
                variations: {
                    wrap: string;
                    direction: string;
                };
            };
        };
        grid: {
            description: string;
            syntax: string;
            template: string;
            initial: string;
            appliesTo: string;
        };
        'align-content': {
            description: string;
            syntax: string;
            template: string;
            initial: string;
            appliesTo: string;
            fabric: {
                classNames: {
                    'flex-align-content': string;
                };
            };
        };
        'align-items': {
            description: string;
            syntax: string;
            template: string;
            initial: string;
            appliesTo: string;
            fabric: {
                classNames: {
                    'align-items': string;
                };
            };
        };
        'align-self': {
            description: string;
            syntax: string;
            template: string;
            initial: string;
            appliesTo: string;
            fabric: {
                classNames: {
                    'align-self': string;
                };
            };
        };
        placeContent: {
            description: string;
            syntax: string;
            template: string;
            initial: string;
            appliesTo: string;
            fabric: {
                classNames: {
                    'place-content': string;
                };
            };
        };
        placeItems: {
            description: string;
            syntax: string;
            template: string;
            initial: string;
            appliesTo: string;
            fabric: {
                classNames: {
                    'place-items': string;
                };
            };
        };
        placeSelf: {
            description: string;
            syntax: string;
            template: string;
            initial: string;
            appliesTo: string;
            fabric: {
                classNames: {
                    'place-self': string;
                };
            };
        };
        order: {
            description: string;
            syntax: string;
            template: string;
            initial: string;
            appliesTo: string;
            fabric: {
                classNames: {
                    order: string;
                };
            };
        };
        masonryAutoFlow: {
            description: string;
            syntax: string;
            template: string;
            initial: string;
            appliesTo: string;
            fabric: {
                classNames: {
                    'masonry-auto-flow': string;
                };
            };
        };
    };
    pointerEvents: {
        description: string;
        syntax: string;
        template: string;
        initial: string;
        appliesTo: string;
        fabric: {
            classNames: {
                'pointer-events': string;
            };
        };
    };
    placement: {
        top: {
            description: string;
            syntax: string;
            template: string;
            initial: string;
            appliesTo: string;
            fabric: {
                classNames: {
                    top: string;
                };
            };
        };
        right: {
            description: string;
            syntax: string;
            template: string;
            initial: string;
            appliesTo: string;
            fabric: {
                classNames: {
                    right: string;
                };
            };
        };
        bottom: {
            description: string;
            syntax: string;
            template: string;
            initial: string;
            appliesTo: string;
            fabric: {
                classNames: {
                    bottom: string;
                };
            };
        };
        left: {
            description: string;
            syntax: string;
            template: string;
            initial: string;
            appliesTo: string;
            fabric: {
                classNames: {
                    left: string;
                };
            };
        };
    };
    box: {
        position: {
            description: string;
            syntax: string;
            template: string;
            initial: string;
            appliesTo: string;
            fabric: {
                classNames: {
                    static: string;
                    relative: string;
                    absolute: string;
                    fixed: string;
                    sticky: string;
                };
            };
        };
        width: {
            description: string;
            syntax: string;
            template: string;
            initial: string;
            appliesTo: string;
            fabric: {
                classNames: {
                    width: string;
                    'min-width': string;
                    'max-width': string;
                };
            };
        };
        height: {
            description: string;
            syntax: string;
            template: string;
            initial: string;
            appliesTo: string;
            fabric: {
                classNames: {
                    height: string;
                    min: string;
                    max: string;
                };
            };
        };
        overflow: {
            description: string;
            syntax: string;
            template: string;
            initial: string;
            appliesTo: string;
            fabric: {
                classNames: {
                    overflow: string;
                    x: string;
                    y: string;
                };
            };
        };
        margin: {
            description: string;
            syntax: string;
            template: string;
            initial: string;
            appliesTo: string;
            fabric: {
                classNames: {
                    margin: string;
                    top: string;
                    right: string;
                    bottom: string;
                    left: string;
                    'top-bottom': string;
                    'right-left': string;
                };
            };
        };
        padding: {
            description: string;
            syntax: string;
            template: string;
            initial: string;
            appliesTo: string;
            fabric: {
                classNames: {
                    padding: string;
                    top: string;
                    right: string;
                    bottom: string;
                    left: string;
                    'top-bottom': string;
                    'right-left': string;
                };
            };
        };
        contain: {
            description: string;
            syntax: string;
            template: string;
            initial: string;
            appliesTo: string;
            fabric: {
                classNames: {
                    contain: string;
                };
            };
        };
        container: {
            description: string;
            syntax: string;
            template: string;
            initial: string;
            appliesTo: string;
            fabric: {
                classNames: {
                    container: string;
                };
            };
        };
        contentVisibility: {
            description: string;
            syntax: string;
            template: string;
            initial: string;
            appliesTo: string;
            fabric: {
                classNames: {
                    'content-visibility': string;
                };
            };
        };
        resize: {
            description: string;
            syntax: string;
            template: string;
            initial: string;
            appliesTo: string;
            fabric: {
                classNames: {
                    resize: string;
                };
            };
        };
        boxSing: {
            description: string;
            syntax: string;
            template: string;
            initial: string;
            appliesTo: string;
            fabric: {
                classNames: {
                    resize: string;
                };
            };
        };
        breakAfter: {
            description: string;
            syntax: string;
            template: string;
            initial: string;
            appliesTo: string;
            fabric: {
                classNames: {
                    'break-after': string;
                };
            };
        };
    };
    filter: {
        description: string;
        syntax: string;
        template: string;
        initial: string;
        appliesTo: string;
        fabric: {
            classNames: {
                none: string;
                blur: string;
                brightness: string;
                contrast: string;
                'drop-shadow': string;
                grayscale: string;
                'hue-rotate': string;
                invert: string;
                opacity: string;
                saturate: string;
                sepia: string;
                url: string;
            };
        };
    };
    opacity: {
        description: string;
        syntax: string;
        template: string;
        initial: string;
        appliesTo: string;
        fabric: {
            classNames: {
                opacity: string;
            };
        };
    };
    transition: {
        description: string;
        syntax: string;
        template: string;
        initial: string;
        appliesTo: string;
        fabric: {
            classNames: {
                transition: string;
                'transition-property': string;
                'transition-duration': string;
                'transition-timing-function': string;
                'transition-delay': string;
            };
        };
    };
    aspectRatio: {
        description: string;
        syntax: string;
        template: string;
        initial: string;
        appliesTo: string;
        fabric: {
            classNames: {
                'aspect-ratio': string;
            };
        };
    };
    colorScheme: {
        description: string;
        syntax: string;
        template: string;
        initial: string;
        appliesTo: string;
        fabric: {
            classNames: {
                'color-scheme': string;
            };
        };
    };
    initialLetter: {
        description: string;
        syntax: string;
        template: string;
        initial: string;
        appliesTo: string;
        fabric: {
            classNames: {
                'initial-letter': string;
            };
        };
    };
    gap: {
        description: string;
        syntax: string;
        template: string;
        initial: string;
        appliesTo: string;
        fabric: {
            classNames: {
                gap: string;
                'row-gap': string;
                'column-gap': string;
            };
        };
    };
    break: {
        'break-after': {
            description: string;
            syntax: string;
            template: string;
            initial: string;
            appliesTo: string;
            fabric: {
                classNames: {
                    'break-after': string;
                };
            };
        };
        'break-before': {
            description: string;
            syntax: string;
            template: string;
            initial: string;
            appliesTo: string;
            fabric: {
                classNames: {
                    'break-before': string;
                };
            };
        };
    };
    backDropFilter: {
        description: string;
        syntax: string;
        template: string;
        initial: string;
        appliesTo: string;
        fabric: {
            classNames: {
                'backdrop-filter-blur': string;
                backdropFilterBrightness: string;
                backdropFilterContrast: string;
                backdropFilterDropShadow: string;
                backdropFilterGrayscale: string;
                backdropFilterHueRotate: string;
                backdropFilterInvert: string;
                backdropFilterOpacity: string;
                backdropFilterSaturate: string;
                backdropFilterSepia: string;
                backdropFilterUrl: string;
            };
        };
    };
    boxShadow: {
        description: string;
        syntax: string;
        template: string;
        initial: string;
        appliesTo: string;
    };
    background: {
        description: string;
        syntax: string;
        template: string;
        initial: string;
        appliesTo: string;
        fabric: {
            classNames: {
                'background-color': string;
                'background-image': string;
                'background-repeat': string;
                'background-attachment': string;
                'background-position': string;
            };
        };
    };
    'unicode-bidi': {
        description: string;
        syntax: string;
        template: string;
        initial: string;
        appliesTo: string;
        fabric: {
            classNames: {
                'unicode-bidi': string;
            };
        };
    };
    'user-select': {
        description: string;
        syntax: string;
        template: string;
        initial: string;
        appliesTo: string;
        fabric: {
            classNames: {
                'user-select': string;
            };
        };
    };
    widows: {
        description: string;
        syntax: string;
        template: string;
        initial: string;
        appliesTo: string;
        fabric: {
            classNames: {
                widows: string;
            };
        };
    };
    'touch-action': {
        description: string;
        syntax: string;
        template: string;
        initial: string;
        appliesTo: string;
        fabric: {
            classNames: {
                'touch-action': string;
            };
        };
    };
    cursor: {
        description: string;
        syntax: string;
        template: string;
        initial: string;
        appliesTo: string;
        fabric: {
            classNames: {
                cursor: string;
            };
        };
    };
    animations: {
        translate: {
            description: string;
            syntax: string;
            template: string;
            initial: string;
            appliesTo: string;
            fabric: {
                classNames: {
                    transform: string;
                };
            };
        };
    };
    'vertical-align': {
        description: string;
        syntax: string;
        template: string;
        initial: string;
        appliesTo: string;
        fabric: {
            classNames: {
                'vertical-align': string;
            };
        };
    };
    visibility: {
        description: string;
        syntax: string;
        template: string;
        initial: string;
        appliesTo: string;
        fabric: {
            classNames: {
                visibility: string;
            };
        };
    };
    borders: {
        border: {
            description: string;
            syntax: string;
            template: string;
            initial: string;
            appliesTo: string;
            fabric: {
                variations: {
                    color: string;
                    style: string;
                    width: string;
                };
            };
        };
        radius: {
            description: string;
            syntax: string;
            template: string;
            initial: string;
            appliesTo: string;
            fabric: {
                classNames: {
                    'border-radius': string;
                    'border-top-left-radius': string;
                    'border-top-right-radius': string;
                    'border-bottom-left-radius': string;
                    'border-bottom-right-radius': string;
                };
            };
        };
        borderWidth: {
            description: string;
            syntax: string;
            template: string;
            initial: string;
            appliesTo: string;
            fabric: {
                classNames: {
                    'border-width': string;
                };
            };
        };
        borderStyle: {
            description: string;
            syntax: string;
            template: string;
            initial: string;
            appliesTo: string;
            fabric: {
                classNames: {
                    'border-style': string;
                };
            };
        };
        borderColor: {
            description: string;
            syntax: string;
            template: string;
            initial: string;
            appliesTo: string;
            fabric: {
                classNames: {
                    'border-color': string;
                };
            };
        };
        outline: {
            description: string;
            syntax: string;
            template: string;
            initial: string;
            appliesTo: string;
            fabric: {
                variations: {
                    color: string;
                    style: string;
                    width: string;
                };
            };
        };
    };
    font: {
        description: string;
        syntax: string;
        template: string;
        initial: string;
        appliesTo: string;
        fabric: {
            classNames: {
                'font-style': string;
                'font-variant': string;
                'font-weight': string;
                'font-size': string;
                'font-family': string;
                'line-height': string;
            };
        };
    };
    rotate: {
        description: string;
        syntax: string;
        template: string;
        initial: string;
        appliesTo: string;
        fabric: {
            classNames: {
                rotate: string;
            };
        };
    };
    scale: {
        description: string;
        syntax: string;
        template: string;
        initial: string;
        appliesTo: string;
        fabric: {
            classNames: {
                transform: string;
            };
        };
    };
    'scroll-snap': {
        'scroll-snap-type': {
            description: string;
            syntax: string;
            template: string;
            initial: string;
            appliesTo: string;
            fabric: {
                classNames: {
                    'scroll-snap-type': string;
                };
            };
        };
        'scroll-snap-align': {
            description: string;
            syntax: string;
            template: string;
            initial: string;
            appliesTo: string;
            fabric: {
                classNames: {
                    'scroll-snap-align': string;
                };
            };
        };
        'scroll-margin': {
            description: string;
            syntax: string;
            template: string;
            initial: string;
            appliesTo: string;
            fabric: {
                classNames: {
                    'scroll-margin': string;
                    top: string;
                    right: string;
                    bottom: string;
                    left: string;
                };
            };
        };
        'scroll-padding': {
            description: string;
            syntax: string;
            template: string;
            initial: string;
            appliesTo: string;
            fabric: {
                classNames: {
                    'scroll-padding': string;
                    top: string;
                    right: string;
                    bottom: string;
                    left: string;
                };
            };
        };
        'scroll-snap-stop': {
            description: string;
            syntax: string;
            template: string;
            initial: string;
            appliesTo: string;
            fabric: {
                classNames: {
                    'scroll-snap-stop': string;
                };
            };
        };
    };
    text: {
        'text-shadow': {
            description: string;
            syntax: string;
            template: string;
            initial: string;
            appliesTo: string;
            fabric: {
                classNames: {
                    'text-shadow': string;
                    'offset-x': string;
                    'offset-y': string;
                    'blur-radius': string;
                    color: string;
                };
            };
        };
        'text-justify': {
            description: string;
            syntax: string;
            template: string;
            initial: string;
            appliesTo: string;
            fabric: {
                classNames: {
                    'text-justify': string;
                };
            };
        };
        'text-indent': {
            description: string;
            syntax: string;
            template: string;
            initial: string;
            appliesTo: string;
            fabric: {
                classNames: {
                    'text-indent': string;
                };
            };
        };
        'text-align': {
            description: string;
            syntax: string;
            template: string;
            initial: string;
            appliesTo: string;
            fabric: {
                classNames: {
                    'text-align': string;
                };
            };
        };
        'text-decoration': {
            description: string;
            syntax: string;
            template: string;
            initial: string;
            appliesTo: string;
            fabric: {
                classNames: {
                    'text-decoration': string;
                };
            };
        };
        'text-transform': {
            description: string;
            syntax: string;
            template: string;
            initial: string;
            appliesTo: string;
            fabric: {
                classNames: {
                    'text-transform': string;
                };
            };
        };
        'text-overflow': {
            description: string;
            syntax: string;
            template: string;
            initial: string;
            appliesTo: string;
            fabric: {
                classNames: {
                    'text-overflow': string;
                };
            };
        };
        whiteSpace: {
            description: string;
            syntax: string;
            template: string;
            initial: string;
            appliesTo: string;
            fabric: {
                classNames: {
                    'white-space': string;
                };
            };
        };
        wordBreak: {
            description: string;
            syntax: string;
            template: string;
            initial: string;
            appliesTo: string;
            fabric: {
                classNames: {
                    'word-break': string;
                };
            };
        };
        wordSpacing: {
            description: string;
            syntax: string;
            template: string;
            initial: string;
            appliesTo: string;
            fabric: {
                classNames: {
                    'word-spacing': string;
                };
            };
        };
        writingMode: {
            description: string;
            syntax: string;
            template: string;
            initial: string;
            appliesTo: string;
            fabric: {
                classNames: {
                    'writing-mode': string;
                };
            };
        };
        hangingPunctuation: {
            description: string;
            syntax: string;
            template: string;
            initial: string;
            appliesTo: string;
            fabric: {
                classNames: {
                    'hanging-punctuation': string;
                };
            };
        };
        initialLetterAlign: {
            description: string;
            syntax: string;
            template: string;
            initial: string;
            appliesTo: string;
            fabric: {
                classNames: {
                    'initial-letter-align': string;
                };
            };
        };
        column: {
            columnCount: {
                description: string;
                syntax: string;
                template: string;
                initial: string;
                appliesTo: string;
                fabric: {
                    classNames: {
                        'column-count': string;
                    };
                };
            };
            columnFill: {
                description: string;
                syntax: string;
                template: string;
                initial: string;
                appliesTo: string;
                fabric: {
                    classNames: {
                        'column-fill': string;
                    };
                };
            };
            columnGap: {
                description: string;
                syntax: string;
                template: string;
                initial: string;
                appliesTo: string;
                fabric: {
                    classNames: {
                        'column-gap': string;
                    };
                };
            };
            'column-rule': {
                description: string;
                syntax: string;
                template: string;
                initial: string;
                appliesTo: string;
                fabric: {
                    classNames: {
                        'column-rule': string;
                        color: string;
                        style: string;
                        width: string;
                    };
                };
            };
            columnRuleColor: {
                description: string;
                syntax: string;
                template: string;
                initial: string;
                appliesTo: string;
                fabric: {
                    classNames: {
                        'column-rule-color': string;
                    };
                };
            };
            columnRuleStyle: {
                description: string;
                syntax: string;
                template: string;
                initial: string;
                appliesTo: string;
                fabric: {
                    classNames: {
                        'column-rule-style': string;
                    };
                };
            };
            columnRuleWidth: {
                description: string;
                syntax: string;
                template: string;
                initial: string;
                appliesTo: string;
                fabric: {
                    classNames: {
                        'column-rule-width': string;
                    };
                };
            };
            columnSpan: {
                description: string;
                syntax: string;
                template: string;
                initial: string;
                appliesTo: string;
                fabric: {
                    classNames: {
                        'column-span': string;
                    };
                };
            };
            columnWidth: {
                description: string;
                syntax: string;
                template: string;
                initial: string;
                appliesTo: string;
                fabric: {
                    classNames: {
                        'column-width': string;
                    };
                };
            };
        };
    };
    zIndex: {
        description: string;
        syntax: string;
        template: string;
        initial: string;
        appliesTo: string;
        fabric: {
            classNames: {
                'z-index': string;
            };
        };
    };
    'tab-size': {
        description: string;
        syntax: string;
        template: string;
        initial: string;
        appliesTo: string;
        fabric: {
            classNames: {
                'tab-size': string;
            };
        };
    };
    table: {
        layout: {
            description: string;
            syntax: string;
            template: string;
            initial: string;
            appliesTo: string;
            fabric: {
                classNames: {
                    layout: string;
                };
            };
        };
        collapse: {
            description: string;
            syntax: string;
            template: string;
            initial: string;
            appliesTo: string;
            fabric: {
                classNames: {
                    collapse: string;
                };
            };
        };
        'border-spacing': {
            description: string;
            syntax: string;
            template: string;
            initial: string;
            appliesTo: string;
            fabric: {
                classNames: {
                    'border-spacing': string;
                };
            };
        };
        'empty-cells': {
            description: string;
            syntax: string;
            template: string;
            initial: string;
            appliesTo: string;
            fabric: {
                classNames: {
                    'empty-cells': string;
                };
            };
        };
        'caption-side': {
            description: string;
            syntax: string;
            template: string;
            initial: string;
            appliesTo: string;
            fabric: {
                classNames: {
                    'caption-side': string;
                };
            };
        };
    };
};
