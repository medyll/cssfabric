import { colorConfig } from './config.js';
import type { Ease, EaseTrigger, Mask, Steps, ToMask } from './types.js';
export declare class CssFabricBuilder {
    cssFabricBuilderParams: CssFabricBuilderParams;
    constructor();
    parseModel(json: Record<string, any>, parentKey?: string): string;
    createProgression(options: {
        property: string;
        steps: {
            steps: Steps;
            presets?: string[];
            ease: [Ease, EaseTrigger];
            reverseValue?: boolean;
        };
        iteratorMask: string;
        propertyValue?: {
            content: [Mask, ToMask];
            apply: string;
        };
    }, format?: 'css' | 'json'): {};
    /**
     * Dispatches elements based on the input mask.
     *
     * @template M - The type of the mask key.
     * @template E - The type of the element.
     * @template A - The type of the value.
     *
     * @param inputMask - The input mask.
     * @param creatorFunction - The function to create the element based on the mask key.
     * @param apply - The function to apply the value to the element.
     */
    dispatchHandleElements<M extends string = string, E = Element, A = any>(inputMask: any[], creatorFunction: (maskKey: M, index: number) => E, apply: (element: E, value: A) => void): void;
    enqueue(callback: (callbackKey: string) => void, ...rest: string[][]): any;
    flattenIt(arr1: string[], arr2: string[], scope?: string): Record<string, any>;
    makeVariation(themeColor: string, variation: string): any;
    makeDefaultVariations(arr1: string[], arr2: string[], prefix: string, vendor?: string): Record<string, any>;
    mainRule(vars: Record<string, any>, prefix: string): Record<string, any>;
}
export declare class CssFabricBuilderParams {
    vendorName: string;
    variations: {
        readonly none: "var({#vendor}-color-##);";
        readonly light: "color-mix(in srgb, var({#vendor}-color-##) white ##%);";
        readonly lighter: "color-mix(in srgb, var({#vendor}-color-##) white ##%);";
        readonly dark: "color-mix(in srgb, var({#vendor}-color-##) black ##%);";
        readonly darker: "color-mix(in srgb, var({#vendor}-color-##) black ##%);";
        readonly complement: "color-mix(in srgb, var({#vendor}-color-##) black ##%);";
        readonly invert: "color-mix(in srgb, var({#vendor}-color-##) black ##%);";
        readonly 'alpha-low': "color-mix(in srgb, var({#vendor}-color-##) transparent ##%);";
        readonly alpha: "color-mix(in srgb, var({#vendor}-color-##) transparent ##%);";
        readonly 'alpha-high': "color-mix(in srgb, var({#vendor}-color-##) transparent ##%);";
    };
    defaultVariationSteps: {
        readonly steps: readonly [0, 100, 10];
        readonly ease: readonly [2, 20];
    };
    correspondances: Record<string, any>;
    baseColors: {
        primary: string;
        secondary: string;
        accent: string;
        neutral: string;
        error: string;
    };
    presets: string[];
    config: typeof colorConfig;
    constructor();
    setVariations(variations: typeof CssFabricBuilderParams.prototype.variations): void;
    setDefaultVariationSteps(variationSteps: typeof CssFabricBuilderParams.prototype.defaultVariationSteps): void;
    private deepMerge;
}
