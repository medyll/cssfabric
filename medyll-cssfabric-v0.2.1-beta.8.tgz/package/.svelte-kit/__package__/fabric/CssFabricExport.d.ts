import type { cssFabricModelType } from './types.js';
export declare class CssFabricExport {
    private cssFabricModel;
    exportPaths: Record<'css' | 'json', string>;
    constructor(cssFabricModel: cssFabricModelType, exportPaths?: CssFabricExport['exportPaths']);
    export(options: CssFabricExport['exportPaths']): void;
    private createCssFile;
    private createJsonModel;
    private parseModel;
}
