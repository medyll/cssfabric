import { SvelteComponentTyped } from "svelte";
declare const __propDef: {
    props: {
        name?: string;
        children?: any[];
        indent?: number;
        data?: Record<string, any>;
    };
    events: {
        [evt: string]: CustomEvent<any>;
    };
    slots: {};
};
export type NewMenuProps = typeof __propDef.props;
export type NewMenuEvents = typeof __propDef.events;
export type NewMenuSlots = typeof __propDef.slots;
export default class NewMenu extends SvelteComponentTyped<NewMenuProps, NewMenuEvents, NewMenuSlots> {
}
export {};
