export type IFabricConfModulePart = Record<string, any>;
export type IFabricConfModuleDataPart = Record<string, any>;
export type IFabricConfModuleMetaDataPart = Record<string, any>;
export type IFabricConfModuleDocsPart = Record<string, any>;
export type TFabricConfModuleDocsAttributesPart = Record<string, any>;
declare const _default: {
    getModuleList: () => Record<string, any>;
    getModuleConfig: (module?: string) => IFabricConfModulePart;
    getModuleData: (module?: string) => IFabricConfModuleDataPart;
    getModuleMetaData: (module?: string) => IFabricConfModuleMetaDataPart;
    getModuleDocs: (module?: string) => IFabricConfModuleDocsPart;
    getModuleDocsAttributes: (module?: string) => TFabricConfModuleDocsAttributesPart;
    getClassNames: {
        getModuleTagClassNames: (props: import("./cssfabricClassNames.js").IListCssfabricClassNamesProps) => Record<string, any> | string[];
        getModuleTagDebug: (props: import("./cssfabricClassNames.js").IListCssfabricClassNamesProps) => Record<string, any> | string[];
    };
    getModuleClassNames: {
        getModuleTagClassNames: (props: import("./cssfabricClassNames.js").IListCssfabricClassNamesProps) => Record<string, any> | string[];
        getModuleTagDebug: (props: import("./cssfabricClassNames.js").IListCssfabricClassNamesProps) => Record<string, any> | string[];
    };
    getModuleTagClassNames: (props: import("./cssfabricClassNames.js").IListCssfabricClassNamesProps) => Record<string, any> | string[];
    getModuleTagDebug: (props: import("./cssfabricClassNames.js").IListCssfabricClassNamesProps) => Record<string, any> | string[];
};
export default _default;
