import cssfabric from './cssfabric.js';
import utils from './utils.js';
function loopIt(props) {
    const { module } = props;
    const moduleAttributes = cssfabric.getModuleDocsAttributes(module);
}
function cssfabricClassNames(props) {
    const { module, moduleAttribute, outputStyle } = props;
    const moduleAttributes = cssfabric.getModuleDocsAttributes(module);
    const fabricAttributes = moduleAttributes[moduleAttribute];
    const moduleTag = fabricAttributes['tag'];
    const moduleKeys = fabricAttributes['keys'] || undefined;
    const moduleLevels = fabricAttributes['levels'] || undefined;
    const moduleLevelsLinked = fabricAttributes['levelsLinked'] || undefined;
    const moduleLevelsExtended = fabricAttributes['levelsDeclin'] || undefined;
    const moduleClassNames = fabricAttributes['classNames'] || undefined;
    let finalOutput = [];
    let finalOutputDebug = {};
    return doParse(outputStyle);
    function doParse(mode) {
        let keyList, levelList, levelListLinked, levelListDeclin;
        const finalOut = [];
        const debugOut = {};
        if (moduleKeys && moduleKeys.length) {
            // beware of any [][]
            keyList = concatenateWithKey(moduleTag, moduleKeys);
        }
        if (moduleLevels && Object.keys(moduleLevels).length) {
            // object !!!
            levelList = Object.keys(moduleLevels)
                .map((level) => {
                let val = moduleLevels[level];
                return concatenateWithKey(level, val);
            })
                .flat();
        }
        if (moduleLevelsLinked && Object.keys(moduleLevelsLinked).length) {
            levelListLinked = Object.keys(moduleLevelsLinked)
                .map((level) => {
                let val = moduleLevelsLinked[level];
                return concatenateWithKey(level, val);
            })
                .flat();
        }
        if (moduleLevelsExtended && Object.keys(moduleLevelsExtended).length) {
            levelListDeclin = Object.keys(moduleLevelsExtended)
                .map((level) => {
                let val = moduleLevelsLinked[level];
                return concatenateWithKey(level, val);
            })
                .flat();
        }
        // prefix all now , and link
        // colors :
        if (keyList && !moduleLevels && !moduleLevelsLinked) {
            // export
            finalOut.push(keyList);
            registerDebug('default', keyList);
        }
        if (moduleKeys && (moduleLevels || moduleLevelsLinked)) {
            // base
            if (moduleLevels) {
                let tg = keyList.map((x) => {
                    let tre = Object.keys(moduleLevels)
                        .map((level) => {
                        let val = moduleLevels[level];
                        let debugKey = x !== '_' && x.toString().charAt(0) !== '_' ? x : level;
                        debugKey = level.toString().charAt(0) === '_' ? debugKey : debugKey + '-' + level;
                        registerDebug(x, concatenateWithKey(debugKey, val), level);
                        return concatenateWithKey(level, val);
                    })
                        .flat(4);
                    return concatenateWithKey(x, tre);
                });
                // is it declinated ? only colors, so nope
                // export
                finalOut.push(tg.flat());
            }
            // if moduleLevelsLinked // only color ?
            if (moduleLevelsLinked) {
                //
                let yt = Object.values(moduleKeys)
                    .map((moduleKey) => {
                    if (moduleKeys.includes(moduleKey)) {
                        let out = [];
                        // linked are here !!
                        registerDebug('linked', concatenateWithKey(moduleTag + '-' + moduleKey, moduleLevelsLinked[moduleKey]), moduleKey);
                        out.push(concatenateWithKey(moduleKey, moduleLevelsLinked[moduleKey]));
                        // is it declinated ?
                        if (moduleLevelsExtended && moduleLevelsExtended[moduleKey]) {
                            //
                            out.push(moduleLevelsLinked[moduleKey]
                                .map((z) => {
                                // iddem
                                registerDebug('declinated', concatenateWithKey(moduleTag + '-' + moduleKey + '-' + z, moduleLevelsExtended[moduleKey]), z);
                                return concatenateWithKey(z, moduleLevelsExtended[moduleKey]);
                            })
                                .flat(2));
                        }
                        // flatten for group here
                        return out.flat(2);
                    }
                })
                    .flat();
                // export
                finalOut.push(concatenateWithKey(moduleTag, yt));
            }
            if (levelListDeclin) {
            } // only colors ? don't go there
        }
        if (!keyList && levelList) {
            // export
            let kkk = concatenateWithKey(moduleTag, levelList);
            finalOut.push(kkk);
        }
        if (moduleClassNames) {
            let kk = parseClassNames();
            let kkk = concatenateWithKey(moduleTag, kk);
            registerDebug('classnames', kk);
            // export
            finalOut.push(kkk);
        }
        if (mode && mode === 'debug') {
            return finalOutputDebug;
        }
        else {
            return finalOut.flat(2);
        }
    }
    function registerDebug(tag, data, nestedTag) {
        if (nestedTag) {
            if (!finalOutputDebug[tag])
                finalOutputDebug[tag] = {};
            finalOutputDebug[tag][nestedTag] = finalOutputDebug[tag][nestedTag]
                ? finalOutputDebug[tag][nestedTag].concat(data)
                : data;
        }
        else {
            finalOutputDebug[tag] = finalOutputDebug[tag] ? finalOutputDebug[tag].concat(data) : data;
        }
    }
    function parseClassNames() {
        return Object.keys(moduleClassNames)
            .map((klass) => {
            return concatenateWithKey(klass, moduleClassNames[klass]);
        })
            .flat();
    }
    function concatenateWithKey(key, levelLine) {
        return levelLine.map((levelTag) => {
            return [key, levelTag]
                .filter((val) => {
                return val !== '_' && val.toString().charAt(0) !== '_';
            })
                .filter((x) => Boolean(x))
                .join('-');
        });
    }
}
export default {
    getModuleTagClassNames: cssfabricClassNames,
    getModuleTagDebug: function doIt(props) {
        props.outputStyle = 'debug';
        return cssfabricClassNames(props);
    }
};
