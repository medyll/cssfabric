function buildReadme(vars) {
    return "readme";
}
export default buildReadme;
