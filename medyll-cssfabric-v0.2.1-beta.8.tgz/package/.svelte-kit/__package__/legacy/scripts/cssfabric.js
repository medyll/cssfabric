import jsonConfig from '../../generated/cssFabric.vars.json';
import cssfabricClassNames from './cssfabricClassNames.js';
//
const getModuleList = () => {
    return jsonConfig['cssfabric']?.['modules'] || {};
};
const getModuleConfig = (module) => {
    if (module)
        return jsonConfig['cssfabric']?.['modules']?.[module] || {};
    return jsonConfig;
};
const getModuleData = (module) => {
    if (module)
        return jsonConfig['cssfabric']?.['modules']?.[module]?.['_data'] || {};
    return jsonConfig;
};
const getModuleMetaData = (module) => {
    if (module)
        return jsonConfig['cssfabric']?.['modules']?.[module]?.['_metadata'] || {};
    return jsonConfig;
};
const getModuleDocs = (module) => {
    if (module)
        return jsonConfig['cssfabric']?.['modules']?.[module]?.['_docs'] || {};
    return jsonConfig;
};
const getModuleDocsAttributes = (module) => {
    if (module)
        return jsonConfig['cssfabric']?.['modules']?.[module]?.['_docs']?.['attributes'] || {};
    return jsonConfig;
};
export default {
    getModuleList,
    getModuleConfig,
    getModuleData,
    getModuleMetaData,
    getModuleDocs,
    getModuleDocsAttributes,
    getClassNames: cssfabricClassNames,
    getModuleClassNames: cssfabricClassNames,
    getModuleTagClassNames: cssfabricClassNames.getModuleTagClassNames,
    getModuleTagDebug: cssfabricClassNames.getModuleTagDebug
};
